import re


def lambda_handler(event, context):
    print("Hello World")
    # print("Client token: " + event['authorizationToken'])
    # print("Method ARN: " + event['methodArn'])